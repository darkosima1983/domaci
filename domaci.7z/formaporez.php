<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Izračunaj cenu</title>
    <style>
        /* Resetovanje margina i paddinga */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        /* Stilizacija tela */
        body {
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Glavni kontejner */
        .container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }

        /* Naslov */
        h2 {
            color: #333;
            margin-bottom: 15px;
        }

        /* Stilizacija labela */
        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
            text-align: left;
        }

        /* Stilizacija input polja i select-a */
        input[type="text"], select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        /* Checkbox container */
        .checkbox-container {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            margin-bottom: 15px;
        }

        /* Checkbox label */
        .checkbox-container label {
            margin-left: 8px;
            font-weight: normal;
        }

        /* Dugme */
        button {
            background: #28a745;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
        }

        /* Hover efekat na dugme */
        button:hover {
            background: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Izračunaj cenu proizvoda</h2>
        <form action="porez.php" method="GET">
            <label for="cena">Unesi cenu proizvoda:</label>
            <input type="text" id="cena" name="cena" placeholder="Unesi cenu proizvoda" required>

            <label for="kategorija">Kategorija proizvoda:</label>
            <select id="kategorija" name="kategorija">
                <option value="hrana">Hrana</option>
                <option value="oprema">Oprema za računare</option>
            </select>

            <div class="checkbox-container">
                <input type="checkbox" id="porez" name="porez">
                <label for="porez">Izračunaj porez</label>
            </div>

            <button type="submit">Izračunaj cenu</button>
        </form>
    </div>
</body>
</html>
