<?php

$base = mysqli_connect("localhost", "root", "", "web_shop");