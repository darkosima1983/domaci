<?php



    $cena = $_GET["cena"];
    $roba = $_GET["kategorija"];
    $ukcena1 = $cena + 50;
    $ukcena2 = $cena + 350;
    $pdv1 = $ukcena1 * 0.1;
    $pdv2 = $ukcena2 * 0.1;

if ( $roba == "hrana" && isset ($_GET["porez"]))
{
    echo $ukcena1 + $pdv1;
}
elseif ($roba == "hrana")
{
    echo $ukcena1;

}
elseif ( $roba == "oprema" && isset ($_GET["porez"]))
{
    echo $ukcena2 + $pdv2;
}
elseif ($roba == "oprema")
{
    echo $ukcena2;

}
else
{
    echo "Niste ineli cenu";
}